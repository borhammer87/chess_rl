# NEXT_CHAT_PROMPT_2026-05-24.md

## GitHub Repository

PASTE YOUR CURRENT STABLE GITHUB REPOSITORY LINK HERE.

---

## IMPORTANT

Read these files FIRST:

1. ARCHITECTURE.md
2. PROJECT_RULES.md
3. PROJECT_STATUS_2026-05-24.md

They are the source of truth.

---

## Current Project State

We are building a Chess Reinforcement Learning project using:

- Python
- PyTorch
- python-chess
- CNN-based DQN
- fixed action space
- experience replay

Current completed components:

- ChessEnv
- RandomAgent
- board_encoder.py
- action_encoder.py
- action_masking.py
- replay_buffer.py
- DQNCNN
- pytest infrastructure

---

## Current Board Encoding

```python
(12, 8, 8)
```

- channels-first
- torch.Tensor output

---

## Current Action Space

```python
4096
```

Formula:

```python
action = from_square * 64 + to_square
```

---

## Current CNN

Input:

```python
(batch_size, 12, 8, 8)
```

Output:

```python
(batch_size, 4096)
```

---

## Current RL Pipeline

```text
ChessEnv
    ↓
board_encoder
    ↓
DQNCNN
    ↓
Q-values
    ↓
legal action masking
    ↓
epsilon-greedy action selection
```

---

## Architectural Constraints

DO NOT:

- redesign architecture
- switch away from CNN
- introduce AlphaZero complexity
- introduce MCTS
- introduce transformers
- optimize prematurely

---

## Immediate Next Step

Implement:

1. DQNAgent
2. epsilon-greedy policy
3. target network
4. Bellman training step
5. optimizer integration
6. minimal training loop

---

## Expected DQN Flow

Bellman target:

Q(s,a) ← r + γ max_a' Q_target(s', a')

Training flow:

```text
sample replay batch
    ↓
policy network Q-values
    ↓
target network Q-values
    ↓
loss computation
    ↓
backpropagation
```

---

## Important

Before writing code:

1. explain the design briefly
2. explain file responsibilities
3. implement incrementally
4. maintain compatibility with current repository structure
