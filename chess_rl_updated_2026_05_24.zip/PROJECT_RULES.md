# PROJECT_RULES.md

## Important Rules

DO NOT:

- redesign architecture
- switch away from CNN
- introduce AlphaZero complexity
- introduce MCTS
- introduce transformers
- optimize prematurely
- refactor stable modules unnecessarily

## Current Technical Decisions

### Board Encoding

- shape: `(12, 8, 8)`
- channels-first
- torch.Tensor output

### Action Space

```python
4096
```

### Legal Move Masking

Masking is applied:

```text
AFTER network inference
BEFORE action selection
```

### Replay Buffer

Replay buffer implementation:

- uses deque
- fixed capacity
- random batch sampling
- Transition dataclass

## Coding Guidelines

- keep modules small
- keep architecture beginner-readable
- use type hints where useful
- add docstrings
- prioritize correctness over optimization
