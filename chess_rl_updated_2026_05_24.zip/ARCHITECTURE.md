# ARCHITECTURE.md

## Project Architecture

```text
src/chess_rl/
│
├── agents/
│   ├── random_agent.py
│   └── dqn_agent.py
│
├── env/
│   └── chess_env.py
│
├── models/
│   └── dqn_cnn.py
│
├── training/
│   └── train_dqn.py
│
├── utils/
│   ├── board_encoder.py
│   ├── action_encoder.py
│   ├── action_masking.py
│   └── replay_buffer.py
```

## Current Model Design

- CNN-based DQN
- Channels-first tensor format
- Fixed action space
- Legal action masking after inference
- Replay buffer for experience replay

## Board Encoding

Input tensor shape:

```python
(12, 8, 8)
```

Represents:

- 6 white piece planes
- 6 black piece planes

Returned as:

```python
torch.Tensor
```

## Action Encoding

Fixed action space size:

```python
4096
```

Formula:

```python
action = from_square * 64 + to_square
```

## Current DQN CNN

Input:

```python
(batch_size, 12, 8, 8)
```

Output:

```python
(batch_size, 4096)
```

## RL Pipeline

```text
ChessEnv
    ↓
board_encoder
    ↓
DQN CNN
    ↓
Q-values
    ↓
legal action masking
    ↓
epsilon-greedy policy
    ↓
ReplayBuffer
    ↓
training step
```
