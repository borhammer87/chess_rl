# DECISIONS

## Packaging

Decision:
- use pyproject.toml
- use editable installation

Reason:
- stable imports
- professional structure

## Imports

NEVER use:
from src.chess_rl...

ALWAYS use:
from chess_rl...

## Architecture

Official structure:
agents/
env/
models/
training/
utils/

## Board encoding

Decision:
board_encoder.py goes inside utils/

Status:
IMPLEMENTED

Reason:
encoding is preprocessing utility

## RL direction

Current next step:
move/action encoding

Initial algorithm:
DQN
