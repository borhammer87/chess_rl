# PROJECT RULES

## Critical rules

### Imports
NEVER use:
from src.chess_rl...

ALWAYS use:
from chess_rl...

## Installation

Always use:
pip install -e .

Never rely on:
- PYTHONPATH hacks
- sys.path.append
- magic working directories

## Folder rules

### utils/
Contains:
- board encoding
- preprocessing
- tensor utilities
- helper functions

board_encoder.py belongs here.

### models/
Contains ONLY:
- neural networks

### training/
Contains ONLY:
- RL training code

## Documentation policy

Whenever architecture changes:
- update ARCHITECTURE.md
- update DECISIONS.md
- update TODO.md


---

# CNN STAGE RULES

## Model Direction

Current official architecture:
- CNN-based DQN

Do NOT:
- migrate to transformers yet
- redesign action space
- introduce AlphaZero-style complexity yet

Priority:
- stable RL infrastructure
- reproducible training pipeline

---

## Tensor Rules

Board encoder output must remain:

```text
(12, 8, 8)
```

PyTorch channels-first convention is mandatory.

---

## Legal Action Rules

The network predicts Q-values for ALL actions.

Illegal actions MUST be filtered after inference using legal action masking.

The model itself is not responsible for legality validation.

---

## Testing Rules

All new models require pytest coverage.

Current recommended tests:
- input shape tests
- output shape tests
- tensor compatibility tests

---

## Environment Rules

Always work inside:

```text
(chess-rl)
```

Never use:
- base environment
- global Python
- system pip
