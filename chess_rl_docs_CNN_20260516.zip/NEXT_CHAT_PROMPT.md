# NEXT CHAT PROMPT

Copy this into the next chat:

We are continuing a Chess Reinforcement Learning project.

IMPORTANT:
Read ARCHITECTURE.md and PROJECT_RULES.md first.
They are the source of truth.

Current state:
- project uses src layout
- package installed with pip install -e .
- imports use from chess_rl...
- Git and GitHub configured
- ChessEnv working
- RandomAgent working
- board_encoder.py already implemented

Official structure:

src/chess_rl/
├── agents/
├── env/
├── models/
├── training/
└── utils/

IMPORTANT:
board_encoder.py is located in:
src/chess_rl/utils/board_encoder.py

Current completed milestone:
- board tensor encoding
- chess.Board -> tensor (8,8,12)

Current priority:
Implement move/action encoding.

Do not change architecture unless explicitly discussed first.
