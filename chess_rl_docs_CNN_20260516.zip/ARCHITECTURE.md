# ARCHITECTURE

## Official structure

src/chess_rl/
├── agents/
├── env/
├── models/
├── training/
└── utils/

## Folder responsibilities

### agents/
- agents
- policies
- action selection logic

### env/
- Chess environment
- game rules
- step/reset logic

### models/
- neural networks
- PyTorch modules

### training/
- training loops
- replay buffers
- optimization

### utils/
- board encoding
- preprocessing
- tensor utilities
- helper functions

IMPORTANT:
- board_encoder.py is implemented inside utils/

## Import rules

CORRECT:
from chess_rl.env.chess_env import ChessEnv

WRONG:
from src.chess_rl...

## Packaging

Project uses:
- pyproject.toml
- editable installation

Install with:
pip install -e .


---

# CNN DQN STAGE UPDATE

## New Model Direction

The project now officially uses a CNN-based DQN architecture instead of an MLP-based model.

Reason:
- chess boards are spatial data
- CNNs naturally learn positional patterns
- more aligned with modern chess RL systems

---

## Current Board Tensor Format

Current encoder output:

```text
(12, 8, 8)
```

Channels-first format for PyTorch CNN compatibility.

Board tensors represent:
- 12 channels
- one channel per piece type/color combination

---

## CNN Model Architecture

Recommended model file:

```text
src/chess_rl/models/dqn_cnn.py
```

Current architecture:

```text
Conv2D
↓
ReLU
↓
Conv2D
↓
ReLU
↓
Flatten
↓
Linear
↓
4096 Q-values
```

---

## RL Inference Pipeline

```text
chess.Board
↓
board_encoder.py
↓
(12,8,8) tensor
↓
CNN DQN
↓
4096 Q-values
↓
legal action masking
↓
move selection
```

---

## Important Design Rule

The neural network DOES NOT validate move legality.

Legal move masking happens AFTER inference.

python-chess / environment logic remains the source of truth for legal moves.

---

## Current Completed Milestones

- ChessEnv implemented
- RandomAgent implemented
- board_encoder.py implemented
- action_encoder.py implemented
- pytest infrastructure working
- VSCode + conda integration fixed
- first CNN DQN architecture implemented
