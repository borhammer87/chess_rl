# BUGS

## FIXED

### ModuleNotFoundError: src

Cause:
- invalid imports
- package not installed

Solution:
- create pyproject.toml
- pip install -e .
- migrate imports

Status:
FIXED

## Potential future bugs

### Board encoding
- board orientation mistakes
- channel ordering mistakes

### Action representation
- illegal move masking
- move index consistency
