# TODO

## DONE

### Infrastructure
- Git setup
- GitHub setup
- pyproject.toml
- editable installation
- imports fixed

### Gameplay
- ChessEnv
- RandomAgent
- random gameplay script

### State representation
- board_encoder.py
- tensor shape (8,8,12)
- piece channel encoding

## CURRENT PRIORITY

### Action representation
- move encoding
- move indexing
- legal move mapping
- action space design

## NEXT STEP

### RL Core
- DQN agent
- replay buffer
- target network

## FUTURE
- self-play
- PPO
- AlphaZero-like system
