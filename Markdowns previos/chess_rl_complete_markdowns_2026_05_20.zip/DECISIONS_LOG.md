# DECISIONS_LOG.md

## Why use 4096 actions?

```python
action = from_square * 64 + to_square
```

Pros:
- simple
- fixed-size output
- beginner-friendly

Cons:
- many illegal actions

Decision:
Keep for initial stable implementation.

---

## Why channels-first?

PyTorch Conv2d expects:
```text
(batch, channels, height, width)
```

Using (12, 8, 8) avoids repeated transpositions.

---

## Why post-inference masking?

Advantages:
- fixed action space
- simple DQN integration
- prevents illegal move selection

---

## Why DQN before AlphaZero?

Goals:
- learn RL fundamentals
- stabilize infrastructure
- understand training pipeline first
