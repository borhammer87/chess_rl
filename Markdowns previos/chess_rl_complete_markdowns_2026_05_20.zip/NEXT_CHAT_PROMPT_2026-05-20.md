# NEXT_CHAT_PROMPT_2026-05-20.md

## GitHub Repository

PASTE YOUR CURRENT STABLE GITHUB REPOSITORY LINK HERE.

---

## IMPORTANT

Read these files FIRST:
1. ARCHITECTURE.md
2. PROJECT_RULES.md
3. ROADMAP.md
4. CURRENT_STATE.md
5. DECISIONS_LOG.md

Treat them as the source of truth.

Do NOT redesign the project.

---

## Current Project State

We are building a Chess Reinforcement Learning project using:
- Python
- PyTorch
- python-chess
- CNN-based DQN

Current status:
- src layout configured
- editable install working
- imports use from chess_rl...
- VSCode + conda integration fixed
- pytest configured and passing
- ChessEnv working
- RandomAgent working
- board_encoder.py implemented
- action_encoder.py implemented
- action_masking.py implemented

---

## Current Encoder Design

Board encoding:
- tensor shape: (12, 8, 8)
- channels-first
- returns torch.Tensor

Action encoding:
```python
action = from_square * 64 + to_square
```

Legal move masking:
- applied AFTER inference
- invalid moves masked before action selection

---

## Current Model Direction

Using:
- CNN + DQN

NOT:
- AlphaZero
- MCTS
- transformers
- policy/value dual heads

Goal:
Build a stable RL training pipeline first.

---

## Completed Milestones

- RL infrastructure stabilized
- environment working
- encoding system completed
- legal action masking completed
- CNN DQN skeleton completed
- tests passing

---

## Architectural Constraints

DO NOT:
- redesign architecture
- change encoder dimensions
- switch away from CNN
- introduce AlphaZero complexity
- optimize prematurely
- refactor stable modules unnecessarily

Prefer incremental improvements only.

---

## Immediate Next Step

Implement:
1. ReplayBuffer
2. DQNAgent
3. epsilon-greedy policy
4. training step
5. target network
6. optimization step
7. minimal training loop

---

## Expected Training Flow

```text
ChessEnv
   ↓
board_encoder
   ↓
CNN DQN
   ↓
Q-values
   ↓
legal action masking
   ↓
epsilon-greedy action selection
   ↓
ReplayBuffer
   ↓
training step
```

---

## IMPORTANT

Before writing code:
1. Explain the design briefly
2. Explain why each file exists
3. Generate code incrementally
4. Maintain compatibility with repository structure
