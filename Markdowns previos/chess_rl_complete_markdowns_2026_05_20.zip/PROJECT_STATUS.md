# PROJECT_STATUS.md

## Completed

- src layout
- editable install
- ChessEnv
- RandomAgent
- board encoder
- action encoder
- action masking
- CNN DQN skeleton
- pytest setup
- tests passing

---

## Current Stable Milestone

RL infrastructure stabilized.

---

## Next Priority

Implement:
1. ReplayBuffer
2. DQNAgent
3. epsilon-greedy policy
4. training step
5. target network
