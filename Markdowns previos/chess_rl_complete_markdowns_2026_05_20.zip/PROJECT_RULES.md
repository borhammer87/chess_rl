# PROJECT_RULES.md

## Core Rules

- Do NOT redesign the architecture.
- Do NOT switch away from CNNs.
- Do NOT introduce AlphaZero complexity yet.
- Prefer incremental improvements.
- Avoid premature optimization.

---

## Coding Rules

- Keep code modular.
- Keep files focused.
- Add docstrings.
- Use type hints when useful.
- Keep architecture beginner-readable.
- Maintain testability.

---

## Testing Rules

- Use pytest.
- Every major component should have tests.
- Stabilize infrastructure before adding complexity.
