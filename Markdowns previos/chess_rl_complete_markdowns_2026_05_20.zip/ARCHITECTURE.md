# ARCHITECTURE.md

## Project

Chess Reinforcement Learning project using:
- Python
- PyTorch
- python-chess
- CNN-based DQN

---

## Current Pipeline

```text
ChessEnv
   ↓
board_encoder
   ↓
CNN DQN
   ↓
Q-values
   ↓
legal action masking
   ↓
epsilon-greedy action selection
   ↓
ReplayBuffer
   ↓
training step
```

---

## Encoder Design

Board tensors:
- shape: (12, 8, 8)
- channels-first
- returns torch.Tensor

Action encoding:
```python
action = from_square * 64 + to_square
```

Total action space:
```text
4096
```

---

## Current Direction

Using:
- CNN
- DQN
- fixed action space
- legal action masking

Not using:
- AlphaZero
- MCTS
- transformers
- policy/value heads
