# ROADMAP.md

# Phase 1 — Infrastructure
Completed:
- environment
- encoders
- masking
- CNN skeleton
- tests

---

# Phase 2 — Functional DQN
Next:
1. ReplayBuffer
2. DQNAgent
3. epsilon-greedy
4. training loop
5. target network

---

# Phase 3 — Stable Training
Future:
- self-play
- reward shaping
- checkpointing
- metrics

---

# Phase 4 — Strength Improvements
Future:
- better CNNs
- hyperparameter tuning
- GPU batching

---

# Phase 5 — Advanced RL
Much later:
- Double DQN
- Dueling DQN
- Prioritized Replay
- AlphaZero experiments
