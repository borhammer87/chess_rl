# NEXT_CHAT_PROMPT_2026-05-19.md

## GitHub Repository

PASTE YOUR CURRENT STABLE GITHUB REPOSITORY LINK HERE.

---

## Prompt

```text
We are continuing a Chess Reinforcement Learning project.

IMPORTANT:
Read ARCHITECTURE.md and PROJECT_RULES.md first.
They are the source of truth.

Current state:
- src layout configured
- editable install working
- imports use from chess_rl...
- ChessEnv working
- RandomAgent working
- board_encoder.py implemented
- action_encoder.py implemented
- action_masking.py implemented
- pytest working
- VSCode + conda integration fixed

Current encoder format:
- board tensor: (12, 8, 8)
- channels-first for CNN compatibility
- returns torch.Tensor

Current action space:
- 4096 actions
- action = from_square * 64 + to_square

Current model direction:
- CNN-based DQN
- legal action masking after inference

Current completed milestone:
- CNN DQN architecture skeleton
- RL infrastructure stabilized
- legal action masking completed
- all tests passing

DO NOT:
- redesign architecture
- switch away from CNN
- introduce AlphaZero complexity yet

Next recommended step:
- DQNAgent
- epsilon-greedy policy
- replay buffer
- training step
```
