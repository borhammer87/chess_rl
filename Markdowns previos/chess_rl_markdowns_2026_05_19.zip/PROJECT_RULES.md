# PROJECT_RULES.md

## Core Rules

- Do NOT redesign architecture.
- Do NOT switch away from CNNs.
- Do NOT introduce AlphaZero complexity yet.

## Stable Decisions

### Encoder
- `(12, 8, 8)`
- channels-first
- `torch.Tensor`

### Action Encoding
- 4096 actions
- `from_square * 64 + to_square`

### Masking
- Applied after Q-network inference.

## Status

Stable as of 2026-05-19.
