# ARCHITECTURE.md

## Project
Chess Reinforcement Learning using Deep Q-Networks (DQN).

## Current Architecture

```text
board
→ board encoder
→ CNN
→ Q-values
→ legal action masking
→ epsilon-greedy action selection
```

## Current Tensor Format

- Shape: `(12, 8, 8)`
- Type: `torch.Tensor`
- Channels-first format

## Action Space

```python
action = from_square * 64 + to_square
```

Total actions:

```text
4096
```

## Current Implemented Systems

- src layout
- editable install
- pytest suite
- ChessEnv
- RandomAgent
- board_encoder
- action_encoder
- action_masking
- CNN DQN skeleton
