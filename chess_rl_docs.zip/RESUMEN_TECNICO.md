Proyecto RL ajedrez inicial.

ChessEnv funcional con python-chess.
RandomAgent implementado.
Script de juego automático funcionando.

No hay aprendizaje aún.
Siguiente paso: arreglar imports y empezar DQN.
