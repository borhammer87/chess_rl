# BUGS

## Import error
No module named 'src'

Causa: PYTHONPATH no configurado

Soluciones:
- PYTHONPATH=src
- instalar como paquete
