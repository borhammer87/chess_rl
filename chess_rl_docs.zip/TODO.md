# TODO

## Hecho
- Entorno conda
- ChessEnv
- RandomAgent
- Script partidas

## En progreso
- Fix imports

## Pendiente
- Board encoder
- DQN
- Replay buffer
- Self-play
