# PROJECT STATE - Chess RL

## 🎯 Objetivo del proyecto
Desarrollar una IA de ajedrez mediante Reinforcement Learning que:
- Aprenda self-play
- Use reglas (python-chess)
- Empiece con DQN
- Entrenable en CPU

## 🧰 Stack
Python 3.11, python-chess, PyTorch, NumPy, tqdm, matplotlib, pytest, conda

## 🏗 Arquitectura
src/chess_rl/env/chess_env.py
src/chess_rl/agents/random_agent.py
scripts/play_random_game.py

## 🧠 Estado actual
ChessEnv implementado
RandomAgent implementado
Script de partidas funcionando

## ❌ No hecho
Tensor representation
DQN
Replay buffer
Self-play training

## ⚠️ Problemas
Imports desde src no resueltos

## 🚀 Próximos pasos
Fix imports
Implement board encoder
Implement DQN
