# DECISIONS

## Estado
python-chess como backend

## Representación
12x8x8 tensor futura

## Reward
+1 win, -1 loss, 0 draw

## Algoritmo
DQN (state-action pairs)

## Entrenamiento
Self-play futuro
