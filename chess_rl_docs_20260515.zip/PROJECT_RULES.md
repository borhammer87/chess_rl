# PROJECT RULES

## Critical rules

### Imports
NEVER use:
from src.chess_rl...

ALWAYS use:
from chess_rl...

## Installation

Always use:
pip install -e .

Never rely on:
- PYTHONPATH hacks
- sys.path.append
- magic working directories

## Folder rules

### utils/
Contains:
- board encoding
- preprocessing
- tensor utilities
- helper functions

board_encoder.py belongs here.

### models/
Contains ONLY:
- neural networks

### training/
Contains ONLY:
- RL training code

## Documentation policy

Whenever architecture changes:
- update ARCHITECTURE.md
- update DECISIONS.md
- update TODO.md
