# ARCHITECTURE

## Official structure

src/chess_rl/
├── agents/
├── env/
├── models/
├── training/
└── utils/

## Folder responsibilities

### agents/
- agents
- policies
- action selection logic

### env/
- Chess environment
- game rules
- step/reset logic

### models/
- neural networks
- PyTorch modules

### training/
- training loops
- replay buffers
- optimization

### utils/
- board encoding
- preprocessing
- tensor utilities
- helper functions

IMPORTANT:
- board_encoder.py is implemented inside utils/

## Import rules

CORRECT:
from chess_rl.env.chess_env import ChessEnv

WRONG:
from src.chess_rl...

## Packaging

Project uses:
- pyproject.toml
- editable installation

Install with:
pip install -e .
